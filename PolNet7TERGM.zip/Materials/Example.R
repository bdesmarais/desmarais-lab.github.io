#### Initial Data Input
### Set the working directory (CHANGE TO DATA LOCATION ON LOCAL COMPUTER)
setwd("~/Dropbox/professional/Teaching/Consulting/PolNet2014TERGM/CodeData/")

### Assure Necessary Packages are Installed
# install.packages(c("ergm","latticeExtra","Matrix"))

### Read in edgelists
## Each one is stored as a two-column (sender, receiver) CSV file
## Each file contains one observation per edge
el1997 <- read.csv("edges1997.csv",stringsAsFactors=F)
el1998 <- read.csv("edges1998.csv",stringsAsFactors=F)
el1999 <- read.csv("edges1999.csv",stringsAsFactors=F)
el2000 <- read.csv("edges2000.csv",stringsAsFactors=F)

### Read in vertex-level dataset
## CCode: COW (Correlates of War) country code
## CName: Country name
## Abb: Three-letter abbreviation 
## GDPXXXX: Real (2000 US dollars) per-capita GDP in year XXXX
vtxDat <- read.csv("nodeData.csv", stringsAsFactors=F)


#### Single-Network Illustration (1999|1998)
# T-1 = 1998
# T = 1999

### Build the network objects
require(network)
## Store the number of vertices
# For this step to work, the vertex dataset
# must have one and only one row per vertex
nv <- nrow(vtxDat)
## Initialize Network objects
net1998 <- network.initialize(nv)
net1999 <- network.initialize(nv)
## Define vertex names in network objects
network.vertex.names(x=net1998) <- vtxDat$Abb
network.vertex.names(x=net1999) <- vtxDat$Abb
## define edges in network objects 
# For this step to work, edgelists must contain vertex
# names that match those stored by network.vertex.names
net1999[as.matrix(el1999)] <- 1
net1998[as.matrix(el1998)] <- 1

### Add in additional data for 1998
##  define *standardized* GDP attribute
# standardize
stdGDP <- (vtxDat$GDP1999-mean(vtxDat$GDP1999))/sd(vtxDat$GDP1999)
# define as vertex attribute
set.vertex.attribute(x=net1999 			# network 
					,attrname="GDP"     # name of attribute
					,val=stdGDP)        # vertex attribute values

### Adding in 4 functions of previous network structure

## lagged network
# models influence of i->j at t-1 on i->j at t
# using [,] after network object extracts adjacency matrix
lNet <- net1998[,]

## Lagged sender and receiver attributes
# sender attribute models the effect of out-going ties at t-1
lSend <- apply(X=lNet,MARGIN=1,FUN=sum)
set.vertex.attribute(x=net1999,attrname="lSend",val=lSend) 

# same for in-coming ties
lRecv <- apply(X=lNet,MARGIN=2,FUN=sum)
set.vertex.attribute(x=net1999,attrname="lRecv",val=lRecv) 

## Shared partners (at least one)
lSP <- lNet%*%lNet + lNet%*%t(lNet) + t(lNet)%*%lNet + t(lNet)%*%t(lNet) > 0


### Single period-period transition TERGM
## Estimate ERGM
require(ergm)
est1 <- ergm(net1999~
		edges					# density
		+edgecov(lNet)			# autocorrelation
		+edgecov(lSP)            # dynamic triangle closure
		+nodeocov("lSend")		# persistent out-degree
		+nodeicov("lRecv")		# persistent in-degree	
		+nodeicov("GDP")		# targeting wealthy states
 		+isolates, 				# unusual number of isolates
 		control=control.ergm(		# simulation tuning
 			MCMC.samplesize=200000,	# networks drawn
 			MCMC.burnin=50000,		# initial throw-away
 			seed=10)) 				# assure replicability

## Check MCMC
# Looking for sample stats similar to observed and non-trending mixed chains
mcmc.diagnostics(est1)

## Check model fit
# looking for black lines through boxplots
gf1 <- gof(est1)
par(mfrow=c(2,2))
plot(gf1)

## summarize estimates
summary(est1)

#### TERGM over multiple time periods (1998|1997, 1999|1998)

### Build all the network objects
## Initialize Networks
net1997 <- network.initialize(nv)
net1998 <- network.initialize(nv)
net1999 <- network.initialize(nv)
net2000 <- network.initialize(nv)
## Define vertex names
network.vertex.names(x=net1997) <- vtxDat$Abb
network.vertex.names(x=net1998) <- vtxDat$Abb
network.vertex.names(x=net1999) <- vtxDat$Abb
network.vertex.names(x=net2000) <- vtxDat$Abb
## define edges
net1997[as.matrix(el1997)] <- 1
net1998[as.matrix(el1998)] <- 1
net1999[as.matrix(el1999)] <- 1
net2000[as.matrix(el2000)] <- 1

##  define *standardized* GDP attribute
set.vertex.attribute(x=net1997,attrname="GDP",val=(vtxDat$GDP1997-mean(vtxDat$GDP1997))/sd(vtxDat$GDP1997)) 
set.vertex.attribute(x=net1998,attrname="GDP",val=(vtxDat$GDP1998-mean(vtxDat$GDP1998))/sd(vtxDat$GDP1998))
set.vertex.attribute(x=net1999,attrname="GDP",val=(vtxDat$GDP1999-mean(vtxDat$GDP1999))/sd(vtxDat$GDP1999)) 
set.vertex.attribute(x=net2000,attrname="GDP",val=(vtxDat$GDP2000-mean(vtxDat$GDP2000))/sd(vtxDat$GDP2000))

## define year attribute
set.vertex.attribute(x=net1997,attrname="year",val=rep(1997,nv))
set.vertex.attribute(x=net1998,attrname="year",val=rep(1998,nv))
set.vertex.attribute(x=net1999,attrname="year",val=rep(1999,nv))
set.vertex.attribute(x=net2000,attrname="year",val=rep(2000,nv))

### Combine multiple time points into the same network

## Initialize network
require(Matrix) # useful block-diagonal construction

## Combine networks, block-by-block
net98_99 <- bdiag(net1998[,],net1999[,]) # constructs block-diagonal 
										 # sparse matrix
net98_99 <- network(as.matrix(net98_99)) # convert to matrix object

## Set existing vertex attributes
# year 
# extract year attributes
yr98 <- get.vertex.attribute(x=net1998			# network
							,attrname="year")	# attribute to extract
yr99 <- get.vertex.attribute(net1999,"year")						
# combine year attributes
yrCombined <- c(yr98,yr99)
# define year attribute in network
set.vertex.attribute(net98_99,"year",yrCombined)

# GDP
set.vertex.attribute(net98_99,"GDP",c(get.vertex.attribute(net1998,"GDP"),get.vertex.attribute(net1999,"GDP")))

## Combine lagged networks, block-by-block
lNet <- as.matrix(bdiag(net1997[,],net1998[,]))

## Lagged sender and receiver attributes
# sender attribute models the effect of out-going ties at t-1
lSend <- apply(X=lNet,MARGIN=1,FUN=sum)
set.vertex.attribute(x=net98_99,attrname="lSend",val=lSend) 

# same for in-coming ties
lRecv <- apply(X=lNet,MARGIN=2,FUN=sum)
set.vertex.attribute(x=net98_99,attrname="lRecv",val=lRecv) 

## Shared partners (direction washed out)
lSP <- lNet%*%lNet + lNet%*%t(lNet) + t(lNet)%*%lNet + t(lNet)%*%t(lNet) > 0


### TERGM Analysis

## Estimate parameters
# Note the 'constraints = ~ blockdiag("year")'
# Constraint removes cross-time elements from analysis
est2 <- ergm(net98_99~
		edges
		+edgecov(lNet)
		+edgecov(lSP)
		+nodeocov("lSend")
		+nodeicov("lRecv")
		+nodeicov("GDP")
 		+isolates, 
 		constraints = ~ blockdiag("year"), ## NOTE CONSTRAINT!!!
 		control=control.ergm(
 			MCMC.samplesize=200000,
 			MCMC.burnin=50000,
 			seed=10))
 			
## Check MCMC
mcmc.diagnostics(est2)

## Check model fit
gf2 <- gof(est2)
par(mfrow=c(2,2))
plot(gf2)

## summarize estimates
summary(est2)

####  Prediction exercise, predicting the network in 2000 
## lagged network
# models influence of i->j at t-1 on i->j at t
lNet <- net1999[,]

### copy over attribute data from net2000
net0 <- network.copy(net2000)
# replace edges
net0[,] <- lNet

## Lagged sender and receiver attributes
# sender attribute models the effect of out-going ties at t-1
lSend <- apply(X=lNet,MARGIN=1,FUN=sum)
set.vertex.attribute(x=net0,attrname="lSend",val=lSend) 

# same for in-coming ties
lRecv <- apply(X=lNet,MARGIN=2,FUN=sum)
set.vertex.attribute(x=net0,attrname="lRecv",val=lRecv) 

## Shared partners (direction washed out)
lSP <- lNet%*%lNet + lNet%*%t(lNet) + t(lNet)%*%lNet + t(lNet)%*%t(lNet) > 0


### Simulate from TERGM estimates
set.seed(12345)
sims <- simulate(net0~ 		# network at which to start
		edges 				# ERGM formula
		+edgecov(lNet)
		+edgecov(lSP)
		+nodeocov("lSend")
		+nodeicov("lRecv")
		+nodeicov("GDP")
 		+isolates,
 		coef=coef(est2), 	# Coefficients to use in sim 
 		nsim=8,				# Number of networks to draw
 		control=control.simulate.formula(MCMC.burnin=50000, MCMC.interval=20000))


### Plot simulated and observed networks
set.seed(12345)
par(mfrow=c(3,3),mar=c(.01,.01,.01,.01))
plot(sims[[1]])
plot(sims[[2]])
plot(sims[[3]])
plot(sims[[4]])
plot(net2000,vertex.col="orange",edge.col="blue",bg="grey85")
plot(sims[[5]])
plot(sims[[6]])
plot(sims[[7]])
plot(sims[[8]])













