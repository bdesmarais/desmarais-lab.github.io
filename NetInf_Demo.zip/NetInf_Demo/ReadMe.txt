Basic instructions for NetInf demo

1. Download demo materials from people.umass.edu/bruced/#teaching
	Note, NetInf for Windows and Linux available at snap.stanford.edu/netinf/

2. decompress NetInf_Demo.zip

3. If you are running Mac, in ./NetInf_Demo, decompress 'netinf-macos.tgz'

4. If you have a C++ compiler installed (e.g., g++), in terminal, change directory to ./NetInf_Demo/netinf

5. type 'make' into the terminal

6. In ./NetInf_Demo, check out 'StateCascades.txt'

7. copy 'StateCascades.txt' into ./NetInf_Demo/netinf

8. type './netinf -e:250 -a:0.5 -i:./StateCascades.txt -s:1' into the terminal, this runs NetInf

9. open './NetInf_Demo/netinf/network-edge.info' in a text editor, this is the output from NetInf

10. open './NetInf_Demo/netinf4causality.R' to see how to run NetInf from R
