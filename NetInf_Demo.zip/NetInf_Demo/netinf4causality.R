# clear R workspace
rm(list=ls())

# set working directory to the netinf directory
setwd("/users/brucedesmarais/Desktop/NetInf_Demo/netinf/")


# use pipe function to operate the terminal (i.e., command line)
# running netinf to infer 250 edges at lambda = 0.5
netinf.pipe <- pipe("./netinf -e:250 -a:0.5 -i:./StateCascades.txt -s:1","r")

# make sure the pipe doesn't close before netinf is done
while(!is.element("network-edge.info",dir())){1}

# close terminal pipe
close(netinf.pipe)

# read in inferred edges
edges <- read.table("network-edge.info",sep="/",header=F,stringsAsFactors=F,skip=1)

# add column names
names(edges) <- c("source", "target", "volume", "marginal_gain", "median_timediff","average_timediff")

# source is the sender of the tie
# target is the receiver of the tie
# volume is the number of cascades in which the edge exists
# marginal_gain is the added value to the likelihood
# median_timediff is the median difference between
## source and target adopting

# make a simple plot of the network
# load the network library
require(network)

# construct a network 
diffusion.net <- network(edges[,c(1,2)])

# plot it using Fruchterman-Reingold force-directed placement
plot(diffusion.net, # the network object
	label=network.vertex.names(diffusion.net), # node labels
	vertex.cex=.0001, # sizing of vertex points
	label.pos=5, # where to put labels relative to vertices
	edge.col="gray70") # lightly colored edges





