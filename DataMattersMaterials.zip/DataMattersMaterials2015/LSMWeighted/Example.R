# Identify path for working directory
wdpath <- "~/Dropbox/professional/Teaching/Past/ICPSR/ICPSRNetworkAnalysis/Lectures/LSM/LSMWeighted/"

# Set the working directory
setwd(wdpath)

# Read in network
el <- read.csv("senELw.csv",stringsAsFactors=F)

# Read in vertex data
dwnom <- read.csv("dwnom1.csv",stringsAsFactors=F)

# Create the network
net <- network.initialize(nrow(dwnom))
network.vertex.names(net) <- dwnom$labs

# Add in edges
# Use only the first two columns of the edge list
net[as.matrix(el[,c(1,2)])] <- 1

# Define vertex attribute
set.vertex.attribute(net,"dwnom",dwnom$dwnom)

# Define edge attribute using weight
set.edge.attribute(net,"eweight",as.numeric(el[,3]))

# Read in ERGM library
library(latentnet)

# Regular LSM without using edge weights 
# Network of any cosponsorships > 0
estBinary <- ergmm(net~euclidean(d=2)+absdiff("dwnom")+sendercov("dwnom")+receivercov("dwnom"),control=control.ergmm(burnin=50000,sample.size=20000))
summary(estBinary)

estCount <- ergmm(net~euclidean(d=2)+absdiff("dwnom")+sendercov("dwnom")+receivercov("dwnom"),control=control.ergmm(burnin=50000,sample.size=20000),response="eweight",family="Poisson.log")
summary(estCount)

estNorm <- ergmm(net~euclidean(d=2)+absdiff("dwnom")+sendercov("dwnom")+receivercov("dwnom"),control=control.ergmm(burnin=50000,sample.size=20000),response="eweight",family="normal.identity")
summary(estNorm)

simCounts <- simulate(estCount,1)

## Plot simulated edge values and true edge values
# Extract simulated weights
sweight <- get.edge.attribute(simCounts,"eweight")
# Initialize simulated adjacency matrix
sAmat <- simCounts[,]
# Extract edgelist (i.e., where to put the weights)
sel <- as.matrix(simCounts,matrix.type="edgelist") 
# Put weights in the adjacency matrix
sAmat[sel] <- sweight

# Extract observed weights
oweight <- get.edge.attribute(net,"eweight")
# Initialize observed adjacency matrix
oAmat <- net[,]
# Extract edgelist (i.e., where to put the weights)
oel <- as.matrix(net,matrix.type="edgelist") 
# Put weights in the adjacency matrix
oAmat[oel] <- oweight

library(sna)
# Use gvectorize to convert adjacency matrix to vector of edge values
# Diagonals show up as NA
sevals <- gvectorize(sAmat)
oevals <- gvectorize(oAmat)
# Simple plot
plot(sevals,oevals,ylab="Observed Weights",xlab="Simulated Weights")

# How correlated are they?
gcor(sAmat,oAmat)

