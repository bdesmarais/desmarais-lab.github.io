# set the working directory
setwd("~/Dropbox/professional/Teaching/Consulting/UNCDataMatters/DataMattersMaterials2015/KrackhardtManagerData/")

# Read in adjacency matrices
## read.csv creates a data frame object from a CSV file
## Need to indicate that there's no header row in the CSV
advice <- read.csv("Advice.csv", header=F)

reportsto <- read.csv("ReportsTo.csv", header = F)

# Read in vertex attribute data
attributes <- read.csv("KrackhardtVLD.csv")

# Read in the library required for ERGM analysis
library(ergm)

# Use the advice network dataset to create network object
adviceNet <- network(advice)

# Add the vertex attributes into the network
set.vertex.attribute(adviceNet,names(attributes),attributes)

# Add the organizational chart as an edge variable
set.network.attribute(adviceNet,"reportsto",as.matrix(reportsto))

## Just basic covariate model
spec0 <- ergm(adviceNet~edges+edgecov("reportsto")+nodeicov("Tenure")+nodeocov("Tenure")+absdiff("Tenure")+nodeicov("Age")+nodeocov("Age")+absdiff("Age"))
# See if the estimates are reliable
# How does it fit?
gf0 <- gof(spec0)
# Make a panel of four plots
par(mfrow=c(2,2))
# plot goodness of fit results
plot(gf0)
# Check out results
summary(spec0)


# Adding reciprocity
# Set the seed for replication
set.seed(5)
spec1 <-ergm(adviceNet~edges+mutual+edgecov("reportsto")+nodeicov("Tenure")+nodeocov("Tenure")+absdiff("Tenure")+nodeicov("Age")+nodeocov("Age")+absdiff("Age"),control=control.ergm(MCMC.samplesize=2000,MCMLE.maxit=10))
# See if the MCMLE Converged
mcmc.diagnostics(spec1)
# See if its degenerate
gf.degeneracy <- gof(spec1, GOF=~model)
summary(gf.degeneracy)
# How does it fit?
gf1 <- gof(spec1)
# Make a panel of four plots
par(mfrow=c(2,2))
# plot goodness of fit results
plot(gf1)
# Check out results
summary(spec1)


# Account for varied activity
# Set the seed for replication
set.seed(5)
spec2 <- ergm(adviceNet~edges+mutual+ostar(2:3)+edgecov("reportsto")+nodeicov("Tenure")+nodeocov("Tenure")+absdiff("Tenure")+nodeicov("Age")+nodeocov("Age")+absdiff("Age"), control=control.ergm(MCMC.samplesize=2000,MCMLE.maxit=10))
# See if the MCMC converged
mcmc.diagnostics(spec2)
# Need longer burnin to converge
spec2 <- ergm(adviceNet~edges+mutual+ostar(2:3)+edgecov("reportsto")+nodeicov("Tenure")+nodeocov("Tenure")+absdiff("Tenure")+nodeicov("Age")+nodeocov("Age")+absdiff("Age"), control=control.ergm(MCMC.burnin=20000,MCMC.samplesize=4000,MCMLE.maxit=10))
# See if the MCMC converged
mcmc.diagnostics(spec2)
# See if its degenerate
gf.degeneracy <- gof(spec2, GOF=~model)
summary(gf.degeneracy)
# How does it fit?
gf2 <- gof(spec2)
# Make a panel of four plots
par(mfrow=c(2,2))
# plot goodness of fit results
plot(gf2)
# Check out results
summary(spec2)


# Now adding transitivity?
# Set the seed for replication
set.seed(5)
spec3 <- ergm(adviceNet~edges+mutual+ostar(2:3)+transitive+edgecov("reportsto")+nodeicov("Tenure")+nodeocov("Tenure")+absdiff("Tenure")+nodeicov("Age")+nodeocov("Age")+absdiff("Age"), control=control.ergm(MCMC.samplesize=2000,MCMLE.maxit=10))


# Use GWESP Instead
# Set the seed for replication
set.seed(5)
spec4 <- ergm(adviceNet~edges+mutual+ostar(2:3)+gwesp(1)+edgecov("reportsto")+nodeicov("Tenure")+nodeocov("Tenure")+absdiff("Tenure")+nodeicov("Age")+nodeocov("Age")+absdiff("Age"), control=control.ergm(MCMC.burnin=20000,MCMC.samplesize=4000,MCMLE.maxit=10))
# See if the MCMC converged
mcmc.diagnostics(spec4)
# See if its degenerate
gf.degeneracy <- gof(spec4, GOF=~model)
summary(gf.degeneracy)
# How does it fit?
gf4 <- gof(spec4)
# Make a panel of four plots
par(mfrow=c(2,2))
# plot goodness of fit results
plot(gf4)
# Check out results
summary(spec4)

# Maybe we can use simple form of GWESP
# Set the seed for replication
set.seed(5)
spec5 <- ergm(adviceNet~edges+mutual+ostar(2:3)+gwesp(0,fixed=T)+edgecov("reportsto")+nodeicov("Tenure")+nodeocov("Tenure")+absdiff("Tenure")+nodeicov("Age")+nodeocov("Age")+absdiff("Age"), control=control.ergm(MCMC.burnin=20000,MCMC.samplesize=4000,MCMLE.maxit=10))
# See if the MCMC converged
mcmc.diagnostics(spec5)
# See if its degenerate
gf.degeneracy <- gof(spec5, GOF=~model)
summary(gf.degeneracy)
# How does it fit?
gf5 <- gof(spec5)
# Make a panel of four plots
par(mfrow=c(2,2))
# plot goodness of fit results
plot(gf5)
# Check out results
summary(spec5)

### See which model fits best
BIC(spec0,spec1,spec2,spec4,spec5)
AIC(spec0,spec1,spec2,spec4,spec5)

### Consider whether ERGM changes logit-based results
summary(spec0)
summary(spec5)

## Are tenure and age the same thing?
plot(get.vertex.attribute(adviceNet,"Age"),get.vertex.attribute(adviceNet,"Tenure"))

